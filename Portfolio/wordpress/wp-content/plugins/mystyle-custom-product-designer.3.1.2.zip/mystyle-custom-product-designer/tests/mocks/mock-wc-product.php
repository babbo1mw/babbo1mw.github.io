<?php

/**
 * Mocks the WC_Product class
 *
 * @package MyStyle
 * @since 1.5.0
 */
class WC_Product {
    public function __construct() {
        //
    }
}
