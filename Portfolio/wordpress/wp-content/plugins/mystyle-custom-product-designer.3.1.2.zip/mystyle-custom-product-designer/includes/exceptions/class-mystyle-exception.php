<?php

/**
 * MyStyle Exception class. 
 * 
 * The MyStyle Exception class is a class for throwing MyStyle Exceptions.
 *
 * @package MyStyle
 * @since 0.2.1
 */
class MyStyle_Exception extends Exception {
    
}
