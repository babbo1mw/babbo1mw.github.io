jQuery(function($) {
	$('#siteorigin-panels-metabox').append('<div class="so-tool-button talon-pb-help" title="Help">' + talon_pb_vars.talon_pb_help + '</div>');
});
